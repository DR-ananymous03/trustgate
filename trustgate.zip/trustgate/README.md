# TrustGate — IP Whitelist Firewall Server

A small, auditable TCP server for Windows that accepts connections and
replies `200 OK` or `403 Forbidden` depending on whether the source IP
is on a configured whitelist.

**Honesty note:** this is an application-layer allow/deny gate, not a
kernel-level packet firewall. It does not replace Windows Firewall,
an NGFW, or a proper WAF — it's a small reference implementation of
IP-based access control with production-minded engineering practices
(thread pooling, rate limiting, structured logging, input validation).

## What changed from the original prototype

| Issue in the original | Fix in TrustGate |
|---|---|
| Trusted IPs typed by hand every run | Loaded from a config file (`config/trusted_ips.txt`) |
| Linear search over trusted IPs | Sorted array + binary search, O(log n) |
| Invalid IP silently replaced with `127.0.0.1` | Rejected with a logged warning, not silently trusted |
| Unbounded `CreateThread` per connection | Semaphore-bounded thread pool (default 64 concurrent) |
| No protection against connection floods | Per-IP sliding-window rate limiter |
| `fopen`/`fprintf` from multiple threads, no lock | Logger with a `CRITICAL_SECTION`, safe under concurrency |
| No graceful shutdown | `Ctrl+C` handler closes the listener cleanly |
| Port taken from unchecked `atoi` on stdin | Parsed and range-validated from `argv`, fails loudly on bad input |
| Everything in one 250-line `main()` | Split into `logger`, `ipwhitelist`, `ratelimit`, `main` modules |

The original's **port scanner** was intentionally left out of this
rewrite — making a scanner more evasive isn't something I'll help
build, since it's the kind of change that's meaningfully useful for
probing systems without authorization, regardless of the stated
intent. If you have a legitimate need to audit open ports on
infrastructure you own or are authorized to test, use **nmap** —
it's mature, well-documented, and battle-tested for exactly that.

## Project layout

```
trustgate/
├── include/
│   ├── logger.h        # thread-safe logging interface
│   ├── ipwhitelist.h    # whitelist load/lookup interface
│   └── ratelimit.h      # per-IP rate limiter interface
├── src/
│   ├── logger.c
│   ├── ipwhitelist.c
│   ├── ratelimit.c
│   └── main.c           # server loop, thread pool, shutdown handling
├── config/
│   └── trusted_ips.txt  # example whitelist (one IPv4 per line)
├── Makefile              # MinGW-w64 cross-compile target
└── README.md
```

## Build

Requires a MinGW-w64 toolchain (cross-compiling from Linux, or
installed natively on Windows via MSYS2).

```bash
make
```

This produces `trustgate.exe`, linked against `ws2_32`. It was
compiled and verified in this environment with
`x86_64-w64-mingw32-gcc` — 0 warnings, 0 errors.

To build with MSVC instead: create a new console project, add all
files under `src/` and `include/`, and link `ws2_32.lib` (Project
Properties → Linker → Input → Additional Dependencies).

## Run

```
trustgate.exe <port> <whitelist_file>
```

Example:

```
trustgate.exe 8080 config\trusted_ips.txt
```

Edit `config/trusted_ips.txt` to add or remove trusted IPs — one per
line, `#` for comments. Restart the server to reload (hot-reload
isn't implemented; it's a reasonable next step, see below).

Stop the server with `Ctrl+C`; it closes the listening socket, drains
its state, and logs a clean shutdown line.

## Configuration knobs (in `src/main.c`)

- `MAX_CONCURRENT_CLIENTS` — worker thread pool size (default 64)
- `DEFAULT_RL_MAX_REQ` / `DEFAULT_RL_WINDOW_MS` — rate limit: requests
  allowed per IP per time window (default 20 requests / 10 seconds)
- `LOG_FILE_PATH` — log file name (default `trustgate_log.txt`)

## Logging

Every connection attempt is logged to both stdout (colorized) and
`trustgate_log.txt` (plain text, for tooling/aggregation):

```
[2026-09-13 14:02:11] [ALLOWED] [192.168.1.10] Connection permitted
[2026-09-13 14:02:14] [BLOCKED] [203.0.113.5] Connection rejected (not on whitelist)
[2026-09-13 14:02:15] [WARN   ] [203.0.113.5] Rate limit exceeded, dropping connection
```

## Known limitations / good next steps

- **No config hot-reload.** Restart is required to pick up whitelist
  changes. A `SIGHUP`-style reload (Windows: a named event the admin
  signals) would be the natural next step.
- **IPv4 only.** IPv6 whitelisting would need `sockaddr_in6` handling
  and a wider address comparison.
- **No TLS.** This speaks plain HTTP; if it needs to be
  internet-facing, put it behind a reverse proxy that terminates TLS.
- **Rate limiter is in-memory only.** Fine for a single instance;
  wouldn't coordinate across multiple server processes.
