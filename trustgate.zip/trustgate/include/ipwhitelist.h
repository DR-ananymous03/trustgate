#ifndef IPWHITELIST_H
#define IPWHITELIST_H

#define IPWL_MAX_ENTRIES 1024
#define IPWL_IP_LEN      16   /* "255.255.255.255\0" */

/*
 * ipwl_load_from_file:
 *   Reads one IPv4 address per line from `filepath`. Blank lines and
 *   lines starting with '#' are ignored (comments). Invalid IPs are
 *   skipped with a warning logged, not silently substituted.
 *
 * Returns the number of valid IPs loaded, or -1 on file error.
 */
int ipwl_load_from_file(const char *filepath);

/*
 * ipwl_is_trusted:
 *   O(log n) lookup via binary search over the sorted whitelist.
 * Returns 1 if trusted, 0 otherwise.
 */
int ipwl_is_trusted(const char *ip);

/* Number of IPs currently loaded. */
int ipwl_count(void);

#endif /* IPWHITELIST_H */
