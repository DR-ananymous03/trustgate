#ifndef LOGGER_H
#define LOGGER_H

#include <windows.h>

/* Log severity levels */
typedef enum {
    LOG_INFO,
    LOG_WARN,
    LOG_ALLOW,
    LOG_BLOCK,
    LOG_ERROR
} log_level_t;

/*
 * logger_init:
 *   Opens the log file and initializes the critical section used to
 *   serialize writes from multiple worker threads.
 *
 * Returns 1 on success, 0 on failure.
 */
int logger_init(const char *filepath);

/*
 * logger_write:
 *   Thread-safe. Writes a single timestamped line to the log file
 *   and mirrors it to stdout with a colored prefix.
 */
void logger_write(log_level_t level, const char *ip, const char *fmt, ...);

/*
 * logger_shutdown:
 *   Flushes and closes the log file, releases the critical section.
 */
void logger_shutdown(void);

#endif /* LOGGER_H */
