#ifndef RATELIMIT_H
#define RATELIMIT_H

/*
 * Simple sliding-window rate limiter keyed by IP string.
 * Protects the server itself from connection floods, independent
 * of whether the source IP is on the trusted whitelist.
 */

#define RATELIMIT_MAX_TRACKED 4096

/*
 * ratelimit_init:
 *   max_requests  - allowed connections per window, per IP
 *   window_ms     - window length in milliseconds
 */
void ratelimit_init(int max_requests, int window_ms);

/*
 * ratelimit_allow:
 *   Thread-safe. Returns 1 if this IP is still under its limit for
 *   the current window (and records the hit), 0 if it should be
 *   rejected.
 */
int ratelimit_allow(const char *ip);

void ratelimit_shutdown(void);

#endif /* RATELIMIT_H */
