/*
 * TrustGate - IP Whitelist Firewall Server
 * ------------------------------------------
 * A small, single-purpose server that accepts TCP connections and
 * replies 200/403 depending on whether the source IP is on a
 * configured whitelist. It is a *filtering front door for your own
 * application*, not a kernel-level packet firewall - it does not
 * replace Windows Firewall, iptables, or a real NGFW, and it should
 * not be marketed as one. Treat it as a small, auditable reference
 * implementation.
 *
 * Build: see Makefile (MinGW-w64 required)
 */

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "logger.h"
#include "ipwhitelist.h"
#include "ratelimit.h"

#ifdef __GNUC__
/* MinGW's linker doesn't need #pragma comment(lib,...); pass -lws2_32
   on the link line instead (see Makefile). MSVC users can uncomment: */
/* #pragma comment(lib, "ws2_32.lib") */
#else
#pragma comment(lib, "ws2_32.lib")
#endif

#define MAX_CONCURRENT_CLIENTS 64
#define DEFAULT_RL_MAX_REQ     20
#define DEFAULT_RL_WINDOW_MS   10000
#define LOG_FILE_PATH          "trustgate_log.txt"

static volatile LONG g_shutdown_requested = 0;
static SOCKET g_server_sock = INVALID_SOCKET;
static HANDLE g_client_slots_sem = NULL; /* bounds concurrent worker threads */

typedef struct {
    SOCKET sock;
    char   ip[INET_ADDRSTRLEN];
} client_ctx_t;

/* ---------------------------------------------------------------- */
/* Graceful shutdown                                                 */
/* ---------------------------------------------------------------- */

static BOOL WINAPI console_handler(DWORD signal) {
    if (signal == CTRL_C_EVENT || signal == CTRL_CLOSE_EVENT) {
        logger_write(LOG_INFO, "-", "Shutdown signal received, closing listener...");
        InterlockedExchange(&g_shutdown_requested, 1);
        if (g_server_sock != INVALID_SOCKET) {
            /* Unblocks the accept() loop in main(). */
            closesocket(g_server_sock);
        }
        return TRUE;
    }
    return FALSE;
}

/* ---------------------------------------------------------------- */
/* Per-connection worker                                             */
/* ---------------------------------------------------------------- */

static void send_response(SOCKET sock, int allowed) {
    static const char *ok =
        "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 22\r\n\r\nTrustGate: Access OK\r\n";
    static const char *denied =
        "HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain\r\nContent-Length: 15\r\n\r\nAccess Denied!\r\n";

    const char *resp = allowed ? ok : denied;
    send(sock, resp, (int)strlen(resp), 0);
}

static DWORD WINAPI client_worker(LPVOID param) {
    client_ctx_t *ctx = (client_ctx_t *)param;

    /* Rate limit first: this protects the server regardless of
       whether the IP is trusted, so a compromised/misbehaving
       trusted host can't flood us either. */
    if (!ratelimit_allow(ctx->ip)) {
        logger_write(LOG_WARN, ctx->ip, "Rate limit exceeded, dropping connection");
        closesocket(ctx->sock);
        free(ctx);
        ReleaseSemaphore(g_client_slots_sem, 1, NULL);
        return 0;
    }

    if (ipwl_is_trusted(ctx->ip)) {
        logger_write(LOG_ALLOW, ctx->ip, "Connection permitted");
        send_response(ctx->sock, 1);
    } else {
        logger_write(LOG_BLOCK, ctx->ip, "Connection rejected (not on whitelist)");
        send_response(ctx->sock, 0);
    }

    closesocket(ctx->sock);
    free(ctx);
    ReleaseSemaphore(g_client_slots_sem, 1, NULL);
    return 0;
}

/* ---------------------------------------------------------------- */
/* Setup helpers                                                     */
/* ---------------------------------------------------------------- */

static int parse_port(const char *s, int *out_port) {
    char *end = NULL;
    long val = strtol(s, &end, 10);
    if (end == s || *end != '\0') return 0;   /* not a clean number */
    if (val < 1 || val > 65535) return 0;
    *out_port = (int)val;
    return 1;
}

static SOCKET create_listening_socket(int port) {
    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) {
        logger_write(LOG_ERROR, "-", "socket() failed: %d", WSAGetLastError());
        return INVALID_SOCKET;
    }

    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (const char *)&opt, sizeof(opt));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons((u_short)port);

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        logger_write(LOG_ERROR, "-", "bind() failed on port %d: %d", port, WSAGetLastError());
        closesocket(sock);
        return INVALID_SOCKET;
    }

    if (listen(sock, SOMAXCONN) == SOCKET_ERROR) {
        logger_write(LOG_ERROR, "-", "listen() failed: %d", WSAGetLastError());
        closesocket(sock);
        return INVALID_SOCKET;
    }

    return sock;
}

static void print_banner(void) {
    printf("\033[1;36m");
    printf("==================================================\n");
    printf("   TrustGate - IP Whitelist Firewall Server        \n");
    printf("==================================================\n");
    printf("\033[0m");
}

/* ---------------------------------------------------------------- */
/* main                                                               */
/* ---------------------------------------------------------------- */

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <port> <whitelist_file>\n", argv[0]);
        fprintf(stderr, "Example: %s 8080 config\\trusted_ips.txt\n", argv[0]);
        return 1;
    }

    int port;
    if (!parse_port(argv[1], &port)) {
        fprintf(stderr, "[-] Invalid port: '%s' (expected 1-65535)\n", argv[1]);
        return 1;
    }
    const char *whitelist_path = argv[2];

    if (!logger_init(LOG_FILE_PATH)) {
        fprintf(stderr, "[-] Could not open log file '%s'\n", LOG_FILE_PATH);
        return 1;
    }

    print_banner();

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        logger_write(LOG_ERROR, "-", "WSAStartup failed");
        logger_shutdown();
        return 1;
    }

    int loaded = ipwl_load_from_file(whitelist_path);
    if (loaded < 0) {
        WSACleanup();
        logger_shutdown();
        return 1;
    }
    logger_write(LOG_INFO, "-", "Loaded %d trusted IP(s) from %s", loaded, whitelist_path);
    if (loaded == 0) {
        logger_write(LOG_WARN, "-", "Whitelist is empty - ALL connections will be blocked");
    }

    ratelimit_init(DEFAULT_RL_MAX_REQ, DEFAULT_RL_WINDOW_MS);

    g_client_slots_sem = CreateSemaphore(NULL, MAX_CONCURRENT_CLIENTS, MAX_CONCURRENT_CLIENTS, NULL);
    if (!g_client_slots_sem) {
        logger_write(LOG_ERROR, "-", "Failed to create semaphore");
        WSACleanup();
        logger_shutdown();
        return 1;
    }

    SetConsoleCtrlHandler(console_handler, TRUE);

    g_server_sock = create_listening_socket(port);
    if (g_server_sock == INVALID_SOCKET) {
        CloseHandle(g_client_slots_sem);
        WSACleanup();
        logger_shutdown();
        return 1;
    }

    logger_write(LOG_INFO, "-", "Listening on port %d (max %d concurrent connections, "
                                 "rate limit %d req / %d ms per IP). Press Ctrl+C to stop.",
                 port, MAX_CONCURRENT_CLIENTS, DEFAULT_RL_MAX_REQ, DEFAULT_RL_WINDOW_MS);

    while (!g_shutdown_requested) {
        struct sockaddr_in client_addr;
        int addr_len = sizeof(client_addr);

        SOCKET client_sock = accept(g_server_sock, (struct sockaddr *)&client_addr, &addr_len);
        if (client_sock == INVALID_SOCKET) {
            if (g_shutdown_requested) break; /* accept() was interrupted by our own close */
            logger_write(LOG_WARN, "-", "accept() failed: %d", WSAGetLastError());
            continue;
        }

        /* Backpressure: block until a worker slot frees up instead of
           spawning unbounded threads under load. */
        WaitForSingleObject(g_client_slots_sem, INFINITE);

        client_ctx_t *ctx = malloc(sizeof(client_ctx_t));
        if (!ctx) {
            logger_write(LOG_ERROR, "-", "Out of memory allocating client context");
            closesocket(client_sock);
            ReleaseSemaphore(g_client_slots_sem, 1, NULL);
            continue;
        }
        ctx->sock = client_sock;

        if (inet_ntop(AF_INET, &client_addr.sin_addr, ctx->ip, sizeof(ctx->ip)) == NULL) {
            strcpy(ctx->ip, "0.0.0.0");
        }

        HANDLE h = CreateThread(NULL, 0, client_worker, ctx, 0, NULL);
        if (!h) {
            logger_write(LOG_ERROR, ctx->ip, "CreateThread failed: %lu", GetLastError());
            closesocket(client_sock);
            free(ctx);
            ReleaseSemaphore(g_client_slots_sem, 1, NULL);
        } else {
            CloseHandle(h); /* detach; worker cleans up its own resources */
        }
    }

    logger_write(LOG_INFO, "-", "Server stopped.");

    if (g_server_sock != INVALID_SOCKET) closesocket(g_server_sock);
    CloseHandle(g_client_slots_sem);
    ratelimit_shutdown();
    WSACleanup();
    logger_shutdown();
    return 0;
}
