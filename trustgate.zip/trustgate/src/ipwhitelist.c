#include <winsock2.h>
#include <ws2tcpip.h>
#include "ipwhitelist.h"
#include "logger.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

static char g_ips[IPWL_MAX_ENTRIES][IPWL_IP_LEN];
static int  g_count = 0;

/* Compares two dotted-quad strings by their actual 32-bit value,
   not lexicographically ("10.0.0.1" < "9.0.0.1" numerically is what
   we want, string compare would get this wrong). */
static int compare_ip(const void *a, const void *b) {
    struct in_addr addr_a, addr_b;
    inet_pton(AF_INET, (const char *)a, &addr_a);
    inet_pton(AF_INET, (const char *)b, &addr_b);
    uint32_t va = ntohl(addr_a.s_addr);
    uint32_t vb = ntohl(addr_b.s_addr);
    if (va < vb) return -1;
    if (va > vb) return 1;
    return 0;
}

static int is_valid_ipv4(const char *ip_str) {
    struct sockaddr_in sa;
    return inet_pton(AF_INET, ip_str, &(sa.sin_addr)) == 1;
}

int ipwl_load_from_file(const char *filepath) {
    FILE *f = fopen(filepath, "r");
    if (!f) {
        logger_write(LOG_ERROR, "-", "Cannot open whitelist file: %s", filepath);
        return -1;
    }

    char line[64];
    g_count = 0;

    while (fgets(line, sizeof(line), f) && g_count < IPWL_MAX_ENTRIES) {
        /* strip newline/carriage return */
        line[strcspn(line, "\r\n")] = '\0';

        /* skip blank lines and comments */
        if (line[0] == '\0' || line[0] == '#') {
            continue;
        }

        if (strlen(line) < IPWL_IP_LEN && is_valid_ipv4(line)) {
            memcpy(g_ips[g_count], line, strlen(line) + 1);
            g_count++;
        } else {
            logger_write(LOG_WARN, "-", "Skipping invalid IP in whitelist: '%s'", line);
        }
    }

    fclose(f);

    if (g_count > 0) {
        qsort(g_ips, g_count, IPWL_IP_LEN, compare_ip);
    }

    return g_count;
}

int ipwl_is_trusted(const char *ip) {
    if (g_count == 0) return 0;

    struct in_addr target;
    if (inet_pton(AF_INET, ip, &target) != 1) return 0;
    uint32_t target_val = ntohl(target.s_addr);

    int lo = 0, hi = g_count - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        struct in_addr mid_addr;
        inet_pton(AF_INET, g_ips[mid], &mid_addr);
        uint32_t mid_val = ntohl(mid_addr.s_addr);

        if (mid_val == target_val) return 1;
        if (mid_val < target_val) lo = mid + 1;
        else hi = mid - 1;
    }
    return 0;
}

int ipwl_count(void) {
    return g_count;
}
