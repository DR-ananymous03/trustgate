#include "ratelimit.h"
#include <windows.h>
#include <string.h>

typedef struct {
    char ip[16];
    int  hits;
    DWORD window_start_ms;
    int  in_use;
} rl_entry_t;

static rl_entry_t g_table[RATELIMIT_MAX_TRACKED];
static CRITICAL_SECTION g_lock;
static int g_max_requests = 20;
static int g_window_ms = 10000;
static int g_initialized = 0;

/* djb2-style hash for a dotted-quad IP string, used to pick a starting
   slot; collisions are resolved with simple linear probing. */
static unsigned int hash_ip(const char *ip) {
    unsigned int h = 5381;
    for (const char *p = ip; *p; p++) {
        h = ((h << 5) + h) + (unsigned char)(*p);
    }
    return h % RATELIMIT_MAX_TRACKED;
}

void ratelimit_init(int max_requests, int window_ms) {
    memset(g_table, 0, sizeof(g_table));
    InitializeCriticalSection(&g_lock);
    g_max_requests = max_requests;
    g_window_ms = window_ms;
    g_initialized = 1;
}

int ratelimit_allow(const char *ip) {
    if (!g_initialized) return 1;

    int allowed = 1;
    DWORD now = GetTickCount();

    EnterCriticalSection(&g_lock);

    unsigned int idx = hash_ip(ip);
    unsigned int start = idx;
    rl_entry_t *slot = NULL;

    /* Linear probe to find an existing entry for this IP, or the
       first free/reusable slot. */
    do {
        rl_entry_t *e = &g_table[idx];
        if (e->in_use && strncmp(e->ip, ip, sizeof(e->ip)) == 0) {
            slot = e;
            break;
        }
        if (!e->in_use && slot == NULL) {
            slot = e;
        }
        idx = (idx + 1) % RATELIMIT_MAX_TRACKED;
    } while (idx != start);

    if (slot == NULL) {
        /* Table full: fail open rather than blocking legitimate
           traffic due to a capacity issue, but this should be rare
           given RATELIMIT_MAX_TRACKED. */
        LeaveCriticalSection(&g_lock);
        return 1;
    }

    if (!slot->in_use) {
        strncpy(slot->ip, ip, sizeof(slot->ip) - 1);
        slot->ip[sizeof(slot->ip) - 1] = '\0';
        slot->in_use = 1;
        slot->hits = 0;
        slot->window_start_ms = now;
    }

    /* Reset window if it has elapsed. */
    if (now - slot->window_start_ms >= (DWORD)g_window_ms) {
        slot->window_start_ms = now;
        slot->hits = 0;
    }

    slot->hits++;
    if (slot->hits > g_max_requests) {
        allowed = 0;
    }

    LeaveCriticalSection(&g_lock);
    return allowed;
}

void ratelimit_shutdown(void) {
    if (!g_initialized) return;
    DeleteCriticalSection(&g_lock);
    g_initialized = 0;
}
