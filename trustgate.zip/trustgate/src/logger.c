#include "logger.h"
#include <stdio.h>
#include <stdarg.h>
#include <time.h>

static FILE *g_log_file = NULL;
static CRITICAL_SECTION g_log_lock;
static int g_initialized = 0;

static void get_timestamp(char *buf, size_t size) {
    SYSTEMTIME st;
    GetLocalTime(&st);
    snprintf(buf, size, "%04d-%02d-%02d %02d:%02d:%02d",
             st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
}

static const char *level_tag(log_level_t level) {
    switch (level) {
        case LOG_INFO:  return "INFO";
        case LOG_WARN:  return "WARN";
        case LOG_ALLOW: return "ALLOWED";
        case LOG_BLOCK: return "BLOCKED";
        case LOG_ERROR: return "ERROR";
        default:        return "UNKNOWN";
    }
}

static const char *level_color(log_level_t level) {
    switch (level) {
        case LOG_ALLOW: return "\033[1;32m"; /* green  */
        case LOG_BLOCK: return "\033[1;31m"; /* red    */
        case LOG_WARN:  return "\033[1;33m"; /* yellow */
        case LOG_ERROR: return "\033[1;31m"; /* red    */
        default:        return "\033[1;37m"; /* white  */
    }
}

int logger_init(const char *filepath) {
    InitializeCriticalSection(&g_log_lock);

    g_log_file = fopen(filepath, "a");
    if (!g_log_file) {
        return 0;
    }

    g_initialized = 1;
    return 1;
}

void logger_write(log_level_t level, const char *ip, const char *fmt, ...) {
    if (!g_initialized) return;

    char timestamp[64];
    get_timestamp(timestamp, sizeof(timestamp));

    char message[512];
    va_list args;
    va_start(args, fmt);
    vsnprintf(message, sizeof(message), fmt, args);
    va_end(args);

    EnterCriticalSection(&g_log_lock);

    /* File output (always plain, no ANSI codes, so it stays readable
       in any text editor or log aggregator). */
    if (g_log_file) {
        fprintf(g_log_file, "[%s] [%-7s] [%s] %s\n",
                timestamp, level_tag(level), ip ? ip : "-", message);
        fflush(g_log_file);
    }

    /* Console output, colorized for the operator watching the terminal. */
    printf("%s[%s] [%-7s] [%s] %s\033[0m\n",
           level_color(level), timestamp, level_tag(level), ip ? ip : "-", message);

    LeaveCriticalSection(&g_log_lock);
}

void logger_shutdown(void) {
    if (!g_initialized) return;

    EnterCriticalSection(&g_log_lock);
    if (g_log_file) {
        fclose(g_log_file);
        g_log_file = NULL;
    }
    LeaveCriticalSection(&g_log_lock);

    DeleteCriticalSection(&g_log_lock);
    g_initialized = 0;
}
